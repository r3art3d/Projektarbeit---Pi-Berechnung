/*
 * init.h
 *
 * Created: 20.03.2018 19:00:55
 *  Author: chaos
 */ 


#ifndef INIT_H_
#define INIT_H_

void vInitClock(void);



#endif /* INIT_H_ */