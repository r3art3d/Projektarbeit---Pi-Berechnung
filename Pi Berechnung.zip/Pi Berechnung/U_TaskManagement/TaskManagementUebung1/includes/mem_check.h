/*
 * mem_check.h
 *
 * Created: 29.07.2011 00:46:29
 *  Author: http://www.rn-wissen.de/index.php/Speicherverbrauch_bestimmen_mit_avr-gcc
 */ 


#ifndef MEM_CHECK_H_
#define MEM_CHECK_H_

extern unsigned short get_mem_unused (void);


#endif /* MEM_CHECK_H_ */