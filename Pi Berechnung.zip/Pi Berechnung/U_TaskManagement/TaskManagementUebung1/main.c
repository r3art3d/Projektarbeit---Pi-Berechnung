/*
 * TaskManagementUebung1.c
 *
 * Created: 20.03.2018 18:32:07
 * Author : Patrik Huber
 */ 

//#include <avr/io.h>
#include "avr_compiler.h"
#include "pmic_driver.h"
#include "TC_driver.h"
#include "clksys_driver.h"
#include "sleepConfig.h"
#include "port_driver.h"

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "event_groups.h"
#include "stack_macros.h"

#include "mem_check.h"

#include "init.h"
#include "utils.h"
#include "errorHandler.h"
#include "NHD0420Driver.h"

#include "ButtonHandler.h"
#include "stdio.h"
#include <string.h> //f�r sprintf
#include "avr_f64.h"
#include "math.h"
#include "event_groups.h"


extern void vApplicationIdleHook( void );
void vCalculatePi1(void *pvParameters);
void vCalculatePi2(void *pvParameters);

void vMenuHandler(void *pvParameters);

TaskHandle_t CalculatePi1Task;
TaskHandle_t CalculatePi2Task;

#define DEMO_EVENT_1 1<<0
#define DEMO_EVENT_2 1<<1

EventGroupHandle_t EventGroup;
uint32_t eventbits = 0x00;

float Timercounter=0;
float Timercounter_Met1=0;
float Timercounter_Met2=0;


// Menu Variables

#define MENU_ID_Init 0
#define MENU_ID_MainMenu 1
#define MENU_ID_PiMenu_Methode_1 2
#define MENU_ID_PiMenu_Methode_2 3

#define MENU_FIRSSTARTINTO MENU_ID_Init

#define MENU_ID__LASTENTRY MENU_ID_PiMenu_Methode_2

int menu_current = MENU_FIRSSTARTINTO;
int menu_MenuDescription_Switch = 1;
int menu_counter = 0;


//Pi Calc Variables

double pi_cal_met1 = 0.0000000000000000000;  
double pi_cal_met2 = 0.0000000000000000000;  

double pi_zwischencal_met1 =0;
double pi_zwischencal_met2 =0;

int operatorswitcher = 0; 

uint64_t n = 0; //Itteration

//int stopped=1;

#define STARTBIT 1<<1 
#define RESETBIT 1<<2

void vApplicationIdleHook( void )
{	
	
}


void vButtonTask(void *pvParameters) {



	PORTF.DIRSET = PIN0_bm; /*LED1*/
	PORTF.DIRSET = PIN1_bm; /*LED2*/
	PORTF.DIRSET = PIN2_bm; /*LED3*/
	PORTF.DIRSET = PIN3_bm; /*LED4*/
	PORTF.OUTSET = 0x0F;
	initButtons();
	vTaskDelay(3000);
	
	for(;;) {
		updateButtons();
		eventbits = xEventGroupGetBits(EventGroup);

		if(getButtonPress(BUTTON1) == SHORT_PRESSED) {
			if (menu_current > MENU_ID_MainMenu){
				menu_current--;
			}
		}
		if(getButtonPress(BUTTON2) == SHORT_PRESSED) {
			if (menu_current < MENU_ID__LASTENTRY){
				menu_current++;
			}
		}
		if(getButtonPress(BUTTON3) == SHORT_PRESSED) {
			if ((eventbits & STARTBIT) == STARTBIT){
				xEventGroupClearBits(EventGroup,STARTBIT);
			}
			else{
				TC0_ConfigClockSource(&TCD0, TC_CLKSEL_DIV1_gc);
				xEventGroupSetBits(EventGroup,STARTBIT);
			}
		}
		if(getButtonPress(BUTTON4) == SHORT_PRESSED) {
			xEventGroupSetBits(EventGroup,RESETBIT);
		}
		if(getButtonPress(BUTTON1) == LONG_PRESSED) {
			if (menu_current > MENU_ID_MainMenu){
				menu_current--;
			}
		}
		if(getButtonPress(BUTTON2) == LONG_PRESSED) {
			if (menu_current < MENU_ID__LASTENTRY){
				menu_current++;
			}
		}
		if(getButtonPress(BUTTON3) == LONG_PRESSED) {
			if ((eventbits & STARTBIT) == STARTBIT){			//Falls STARTBIT gesetzt
				xEventGroupClearBits(EventGroup,STARTBIT); //L�sche STARTBIT
			}
			else{
				TC0_ConfigClockSource(&TCD0, TC_CLKSEL_DIV1_gc);
				xEventGroupSetBits(EventGroup,STARTBIT); // Setze STARTBIT
			}
		}
		if(getButtonPress(BUTTON4) == LONG_PRESSED) {
			xEventGroupSetBits(EventGroup,RESETBIT);
		}
	vTaskDelay((1000/BUTTON_UPDATE_FREQUENCY_HZ)/portTICK_RATE_MS);
	}
}

int main(void)
{
    resetReason_t reason = getResetReason();

	vInitClock();
	vInitDisplay();

	EventGroup = xEventGroupCreate();
	eventbits = xEventGroupGetBits(EventGroup);
	xEventGroupClearBits(EventGroup,STARTBIT);

	xTaskCreate( vCalculatePi1, (const char *) "CalculatePi1", configMINIMAL_STACK_SIZE+300, NULL, 1, &CalculatePi1Task);
	xTaskCreate( vButtonTask, (const char *) "btTask", configMINIMAL_STACK_SIZE, NULL, 2, NULL);
	xTaskCreate( vMenuHandler, (const char *) "MenuHandler", configMINIMAL_STACK_SIZE+600, NULL, 3, NULL);

	vTaskStartScheduler();

}

void vCalculatePi1(void *pvParameters) {
	(void) pvParameters;
	 uint64_t powercal = 16;
	TC0_ConfigClockSource(&TCD0,TC_CLKSEL_OFF_gc);
	TC0_ConfigWGM(&TCD0, TC_WGMODE_NORMAL_gc);
	TC_SetPeriod(&TCD0, 0x7CFF);
	TC0_SetOverflowIntLevel(&TCD0,TC_OVFINTLVL_MED_gc);

	
	int Timercounter_Met1_Stop=0;
	int Timercounter_Met2_Stop=0;
 	for(;;) {
		uint32_t taskStack = uxTaskGetStackHighWaterMark(CalculatePi1Task);
		uint32_t stack = get_mem_unused();
		uint32_t heap = xPortGetFreeHeapSize();
		
		eventbits = xEventGroupGetBits(EventGroup);
		
			if((eventbits & RESETBIT) == RESETBIT){
				pi_cal_met1=0;
				pi_cal_met2=0;
				pi_zwischencal_met1=0;
				pi_zwischencal_met2=0;
				Timercounter_Met1=0;
				Timercounter_Met2=0;
				Timercounter_Met1_Stop = 0;
				Timercounter_Met2_Stop = 0;
				n=0;
				operatorswitcher=0;
				xEventGroupClearBits(EventGroup,RESETBIT);
				xEventGroupClearBits(EventGroup,STARTBIT);
				TC0_ConfigClockSource(&TCD0, TC_CLKSEL_OFF_gc);
				Timercounter = 0;
			}
			

			if(((eventbits & STARTBIT) == STARTBIT)){

				if (operatorswitcher==0){
					pi_zwischencal_met1 += (double) 1.0 / (2.0*n + 1.0);
					operatorswitcher=1;
				}
				else{
					pi_zwischencal_met1 -= (double) 1.0 / (2.0*n + 1.0);
					operatorswitcher=0;
				}

				pi_cal_met1 = (double) pi_zwischencal_met1 * 4.0;
				
				if (((pi_cal_met1 <= 3.141599 && pi_cal_met1 >= 3.141590)) && (Timercounter_Met1_Stop == 0) ){
					TC0_ConfigClockSource(&TCD0, TC_CLKSEL_OFF_gc);
					Timercounter_Met1 = Timercounter;
					Timercounter_Met1_Stop = 1;
				}
		

				pi_cal_met2 += (double) (1.0/pow(16.0,n))*(((double)4.0/(8.0*n+1.0)) - ((double)2.0/(8.0*n+4.0)) - ((double)1.0/(8.0*n+5.0)) - ((double)1.0/(8.0*n+6.0)));
				
				if (((pi_cal_met2 <= 3.141599 && pi_cal_met2 >= 3.141590)) && (Timercounter_Met2_Stop == 0) ){
					Timercounter_Met2 = Timercounter;
					Timercounter_Met2_Stop = 1;
				}
				
				if(n < 0xFFFFFFFFFFFFFFFF)
					n++;
				}
				else{
		 			 TC0_ConfigClockSource(&TCD0, TC_CLKSEL_OFF_gc);
				}
		
 			}


}


void vMenuHandler(void *pvParameters) {
	(void) pvParameters;
	char PIstring[18];
	char PIstring1[18];

	for (;;){
		
	updateButtons();

	if ((menu_counter == 4) && (menu_current > MENU_ID_MainMenu)){
		vDisplayClear();
		if (menu_current >= MENU_ID_MainMenu){
			if (menu_MenuDescription_Switch == 0){
				vDisplayWriteStringAtPos(3,0, "S2: Naechste Seite");
				menu_MenuDescription_Switch = !menu_MenuDescription_Switch;
			}
			else{
				vDisplayWriteStringAtPos(3,0, "S1: Letzte Seite  ");
				menu_MenuDescription_Switch = !menu_MenuDescription_Switch;
			}
		}
		menu_counter = 0;
	}
	else{
		if ((menu_current > MENU_ID_MainMenu)){
			menu_counter++;
		}
		vDisplayWriteStringAtPos(0,0, "                    ");
		vDisplayWriteStringAtPos(1,0, "                    ");
		vDisplayWriteStringAtPos(2,0, "                    ");
	}
	
	switch (menu_current){
		
		case MENU_ID_Init:
		vDisplayWriteStringAtPos(0,0, "Pi Calc");
		vDisplayWriteStringAtPos(2,0, "Press S2 to Start");
		break;
		
		case MENU_ID_MainMenu:
		vDisplayClear();
		vDisplayWriteStringAtPos(0,0, "Pi Calc - Hauptmenu");
		vDisplayWriteStringAtPos(1,0, "Menu 1: Methode 1");
		vDisplayWriteStringAtPos(2,0, "Menu 2: Methode 2");
		vDisplayWriteStringAtPos(3,0, "von P.Huber      S2>");
		break;

		case MENU_ID_PiMenu_Methode_1:
		vDisplayWriteStringAtPos(0,0, "Pi Calc - Methode 1");
		sprintf(PIstring, "%.3fs(%.1fs)" ,Timercounter_Met1, Timercounter);
		vDisplayWriteStringAtPos(1,0, "Zeit: %s", PIstring);
		vDisplayWriteStringAtPos(2,0, "Pi:");
		sprintf(PIstring, "%.7lf" ,pi_cal_met1);
		vDisplayWriteStringAtPos(2,4, PIstring);
		break;
		
		case MENU_ID_PiMenu_Methode_2:
		vDisplayWriteStringAtPos(0,0, "Pi Calc - Methode 2");
		sprintf(PIstring, "%.3fs(%.1fs)" ,Timercounter_Met2, Timercounter);
		vDisplayWriteStringAtPos(1,0, "Zeit: %s", PIstring);
		vDisplayWriteStringAtPos(2,0, "Pi:");
		sprintf(PIstring1, "%.7lf" ,pi_cal_met2);
		vDisplayWriteStringAtPos(2,4, PIstring1);
		break;
		
		default:
		menu_current=1;
		break;
		
	}
	
	vTaskDelay(500);

	}

}

ISR(TCD0_OVF_vect){
	Timercounter= Timercounter + 0.001;
}